unzip bgltheme.zip into your C:\Program Files\Plus!\Themes and open
through your desktop themes in your control panel.