In order to install the Battlestar Galactica Theme, just copy all the files in the
self-extracting file into your <drive>:\Plus!\Themes directory.  Then, in Control Panel,
select Desktop Themes and choose the Battlestar Galactica theme from the drop down menu.

If you have comments, questions or suggestions, please e-mail proy@microsoft.com

